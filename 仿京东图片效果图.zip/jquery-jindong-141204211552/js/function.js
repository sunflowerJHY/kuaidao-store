// JavaScript Document

//解决getElementsByClassName在IE6下不显示的问题
function getClass(classname,obj){
	var obj=obj||document;
	var arr=[];
	if(obj.getElementsByClassName){
		return obj.getElementsByClassName(classname);
		}else{
			var alls=obj.getElementsByTagName("*");//获得页面中所有标签
			for(var i=0;i<alls.length;i++){
				if(checkclass(alls[i].className,classname)){
					arr.push(alls[i]);
					}
				}
				return arr;
			}
			
	}
	
/*检查类名是否存在
	newclass   要找的类名
	oldclass   本来的类名*/
function checkclass(oldclass,newclass){
	var oldArr=oldclass.split(" ");
	for(var i=0;i<oldArr.length;i++){
		 if(oldArr[i]==newclass){
			 return true;
			 }
		}
		return false;
	}
function $(a){
	if(typeof a=="string"){
		 var a=a.replace(/^\s*|\s*$/g,"");
		 //用Id获取
		 if(a.charAt(0)=="#"){
			  return document.getElementById(a.slice(1));
			 }
			if(a.charAt(0)=="."){
				return document.getElementsByClassName(a.slice(1));
				}
		}
	}
/*寻找对象*/
function $(selector,obj){
	var obj=obj||document;
	//修正参数
	if(typeof selector=="string"){
		 //修正参数去空格
		 var selector=selector.replace(/^\s*|\s*$/g,"");
		 
		 //用id获取
		 if(selector.charAt(0)=="#"){
			 return obj.getElementById(selector.slice(1),obj);
			 }
		//通过标签名获取
		if(/^[a-zA-Z]{1,10}$/.test(selector)){
			  return obj.getElementsByTagName(selector,obj);
			}
		//通过类名获取
		if(selector.charAt(0)=="."){
			 return getClass(selector.slice(1),obj);
			
			}
			 
			 
		}
		
		if(typeof selector=="function"){
				window.onload=function(){
					selector();
					}
			}
		
	
	
	
	
	}
/*获得对象的纯文本
 obj要获取的对象
 val设置的值的
 传入俩个值是设置
 传入一个值是获取
 解决IE6中不支持textContent和火狐中不支持innerText
*/
function getText(obj,val){
	if(obj.textContent!=undefined){//支持textContent在火狐里面	
	if(val!=undefined){
		 obj.textContent=val; 
		}else{
			return obj.textContent;
			}
		}else{
			if(val!=undefined){
				 obj.innerText=val;
				
				}else{
			 return obj.innerText;
			 
				}
			}
	
	}
	
/*获取元素的样式的属性兼容ie6和火狐
	在火狐下面
	alert(window.getComputedStyle($("div")[0],null)["width"])
	
	在Ie下
	alert($("div")[0].currentStyle.width)
	obj获取得对象
	val获取的是哪一个的对象
*/
function getStyle(obj,val){
	
	if(obj.currentStyle){
		  return parseInt(obj.currentStyle[val]);
		}else{
			 return parseInt(getComputedStyle(obj,null)[val]);
			}
	
	}
	

/*点击图片图片出现的动画*/
/*function animate(obj,attr,end,callback){
	clearInterval(obj.t);
	obj.t=setInterval(function(){
		 var init=getStyle(obj,attr);
		 var speed=(end-init)/8>0?Math.ceil((end-init)/8):Math.floor((end-init)/8);
		 if(Math.abs(speed)==1){
			  clearInterval(obj.t);
			  obj.style[attr]=end+"px";
			   if(callback){
					 callback();
					 }
			 }else{
				 obj.style[attr]=init+speed+"px";
				
				 }
		},60)
	
	}*/
	
function tab(btns,cons){
	
	
	
	}