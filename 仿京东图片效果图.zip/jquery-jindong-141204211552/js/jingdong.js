$(function  () {
	var box=$(".box")[0]
	var imgs=$("img",box);
	box.onmouseout=function  () {
		  for (var i=0; i<imgs.length; i++){
		  animate(imgs[i],{left:0,opacity:1},100);
		 }
	}
	for (var i=0; i<imgs.length; i++) {
		  
		  imgs[i].onmouseover=function  () {
			 
			 for (var j=0; j<imgs.length; j++) {
			 animate(imgs[j],{left:0,opacity:0.7},100);
			  
			 }
             animate(this,{left:-15,opacity:1},100);
			
		  }
	
	}
})